// DATA SAMPLE
var DATA = [
    {
        TYPE: 'ADD_CLASS',
        SELECTOR_CSS_LIST_BY_COMMA: 'body',
        CLASS_LIST_BY_SPACE: 'UPPER w3-white'
    },
    {
        TYPE: 'ADD_CLASS',
        SELECTOR_CSS_LIST_BY_COMMA: 'h1',
        CLASS_LIST_BY_SPACE: 'w3-text-blue w3-xxlarge LINE_HEIGHT_110'
    },
    {
        TYPE: 'ADD_CLASS',
        SELECTOR_CSS_LIST_BY_COMMA: 'h2',
        CLASS_LIST_BY_SPACE: 'w3-text-blue w3-xlarge LINE_HEIGHT_110'
    },
    {
        TYPE: 'ADD_CLASS',
        SELECTOR_CSS_LIST_BY_COMMA: 'h3',
        CLASS_LIST_BY_SPACE: 'w3-text-green w3-large LINE_HEIGHT_110'
    },
    {
        TYPE: 'ADD_CLASS',
        SELECTOR_CSS_LIST_BY_COMMA: 'h4',
        CLASS_LIST_BY_SPACE: 'w3-text-green w3-medium LINE_HEIGHT_110'
    },
    {
        TYPE: 'ADD_CLASS',
        SELECTOR_CSS_LIST_BY_COMMA: 'pre,pre code,code',
        CLASS_LIST_BY_SPACE: 'CONG_CODE'
    },
    {EMPTY_LINE: 'EMPTY_LINE'}
];
//
/* CONG JS SHORT.V?.js | FOR INJECTION WORK | 1 LINE | FUNCTIONS LIST: SELECT, GET_CDN_LINK, INJECTION_ADD_CSS_LIBRARY, INJECTION_ADD_JAVASCRIPT_LIBRARY, INJECTION_ADD_JAVASCRIPT_DATA */ function SELECT(SELECTOR_CSS) { return document.querySelector(SELECTOR_CSS); } function GET_CDN_LINK(PATH_FILE) { return 'https://gitcdn.link/cdn/congnq92/ADD-LOOK-TO-TRAINING-WEBSITE/main' + PATH_FILE; } function INJECTION_ADD_CSS_LIBRARY(PATH_FILE) { var CSS_ELEMENT = document.createElement('link'); CSS_ELEMENT.rel = 'stylesheet'; CSS_ELEMENT.href = GET_CDN_LINK(PATH_FILE); SELECT('head').appendChild(CSS_ELEMENT); } function INJECTION_ADD_JAVASCRIPT_LIBRARY(PATH_FILE){ var JAVASCRIPT_ELEMENT = document.createElement('script'); JAVASCRIPT_ELEMENT.src = GET_CDN_LINK(PATH_FILE); SELECT('head').appendChild(JAVASCRIPT_ELEMENT); } function INJECTION_ADD_JAVASCRIPT_DATA(JAVASCRIPT_TEXT){ const JAVASCRIPT_ELEMENT = document.createElement("script"); JAVASCRIPT_ELEMENT.appendChild(document.createTextNode(JAVASCRIPT_TEXT)); SELECT('head').appendChild(JAVASCRIPT_ELEMENT); }
INJECTION_ADD_CSS_LIBRARY('/CSS/CSS_ALL.V1.4.css');
INJECTION_ADD_JAVASCRIPT_LIBRARY('/JAVASCRIPT/CONG/CONG_JS.V1.49.js');
INJECTION_ADD_JAVASCRIPT_DATA('var DATA=' + JSON.stringify(DATA) + ';');