const CSS = ".CONG_WORDS, h1, h2, h3, h4 {text-transform: uppercase;word-spacing: 4px;font-weight: 444;color:#000;background:#fff}.CONG_CODE .codeblock, .CONG_CODE code {text-transform:none}";
const CSS_API_PLATFORM_SITE = "#ukraine-message{display:none;} .doc-header-container{display:none;} .doc-sidebar-highlight{display:none;} .top-horizontal-highlights{display:none;} body{margin-top:0 !important; padding-top: 0 !important;} #sln {display:none;}  .doc-content-embedded-sidebar {display: none !important;} .doc-license {display: none;} footer {display:none;} .doc-content{padding: 0 !important;} .ui-prose{max-width: 100%;}";
const STYLE = document.createElement("style");
STYLE.appendChild(document.createTextNode(CSS + CSS_API_PLATFORM_SITE));
document.querySelector('body').appendChild(STYLE);
// --- END STYLE ---
document.querySelector('body').classList.add("CONG_WORDS");
document.querySelector('body').classList.add("CONG_CODE");