var DATA = [
    {
        TYPE: 'ADD_CLASS',
        SELECTOR_CSS_LIST_BY_COMMA: 'body',
        CLASS_LIST_BY_SPACE: 'UPPER w3-white w3-text-black'
    },
    {
        TYPE: 'ADD_CLASS',
        SELECTOR_CSS_LIST_BY_COMMA: '.orb-footer,.bbcle-footer-nav-wrapper,#_highlight-index-footer-nav,#bbcle-header,.widget-iconrichtext-download',
        CLASS_LIST_BY_SPACE: 'HIDE'
    },
    {
        TYPE: 'ADD_CLASS',
        SELECTOR_CSS_LIST_BY_COMMA: '#bbcle-header-nav .open',
        CLASS_LIST_BY_SPACE: 'w3-blue'
    },
    {
        TYPE: 'ADD_CLASS',
        SELECTOR_CSS_LIST_BY_COMMA: '.item.item-session.active',
        CLASS_LIST_BY_SPACE: 'w3-card w3-margin-bottom w3-round'
    },
    {
        TYPE: 'ADD_CLASS',
        SELECTOR_CSS_LIST_BY_COMMA: 'span[data-i18n-message-id=\'Completed\']',
        CLASS_LIST_BY_SPACE: 'w3-green w3-padding w3-xxlarge'
    },
    {
        TYPE: 'ADD_CLASS',
        SELECTOR_CSS_LIST_BY_COMMA: '.widget-video-standard,.widget-audio-standard',
        CLASS_LIST_BY_SPACE: 'w3-card w3-round w3-border w3-border-green'
    },
    {
        TYPE: 'ADD_CLASS',
        SELECTOR_CSS_LIST_BY_COMMA: '#richtext-hideable-toggle-12-show,#richtext-hideable-toggle-12-hide,.button-begin,.button-proceed,.button-standard.next-question,.widget-pagelink-next-activity a',
        CLASS_LIST_BY_SPACE: 'w3-button w3-green w3-round'
    },
    {
        TYPE: 'ADD_CLASS',
        SELECTOR_CSS_LIST_BY_COMMA: '.game-wrapper',
        CLASS_LIST_BY_SPACE: 'w3-card w3-round w3-pale-green'
    },
    {
        TYPE: 'ADD_CLASS',
        SELECTOR_CSS_LIST_BY_COMMA: '.game-summary',
        CLASS_LIST_BY_SPACE: 'w3-card w3-round w3-blue'
    },
    {
        TYPE: 'ADD_CLASS',
        SELECTOR_CSS_LIST_BY_COMMA: '.choice.selected',
        CLASS_LIST_BY_SPACE: 'w3-blue'
    },
    {
        TYPE: 'ADD_CLASS',
        SELECTOR_CSS_LIST_BY_COMMA: '.choice.selected.locked.correct',
        CLASS_LIST_BY_SPACE: 'w3-green'
    },
    {
        TYPE: 'ADD_CLASS',
        SELECTOR_CSS_LIST_BY_COMMA: '.choice.selected.locked.incorrect',
        CLASS_LIST_BY_SPACE: 'w3-red'
    },
    {
        TYPE: 'ADD_CLASS',
        SELECTOR_CSS_LIST_BY_COMMA: '.widget-bbcle-activitytitle h3',
        CLASS_LIST_BY_SPACE: 'w3-text-blue w3-jumbo'
    },
    {
        TYPE: 'ADD_CLASS',
        SELECTOR_CSS_LIST_BY_COMMA: '#widget-richtext-hideable-12 .text',
        CLASS_LIST_BY_SPACE: 'w3-card w3-pale-blue w3-text-indig'
    },
    {
        TYPE: 'ADD_CLASS',
        SELECTOR_CSS_LIST_BY_COMMA: '#widget-richtext-hideable-12 .text strong',
        CLASS_LIST_BY_SPACE: 'w3-text-red'
    },
    {
        TYPE: 'ADD_CLASS',
        SELECTOR_CSS_LIST_BY_COMMA: '.widget.widget-richtext',
        CLASS_LIST_BY_SPACE: 'w3-card w3-pale-green w3-padding w3-margin'
    },
    {
        TYPE: 'ADD_CLASS',
        SELECTOR_CSS_LIST_BY_COMMA: '.widget.widget-richtext h3',
        CLASS_LIST_BY_SPACE: 'w3-blue w3-padding w3-xxxlarge w3-round w3-margin-top'
    },
    {
        TYPE: 'ADD_CLASS',
        SELECTOR_CSS_LIST_BY_COMMA: '.widget.widget-richtext strong',
        CLASS_LIST_BY_SPACE: 'w3-yellow w3-text-red w3-xxlarge w3-round'
    },
    {
        TYPE: 'ADD_CSS',
        SELECTOR_CSS_LIST_BY_COMMA: '#bbcle-content div .widget-container:nth-of-type(5),.widget-container.widget-container-right',
        CSS_TEXT: 'width: 100%;'
    },
    {
        TYPE: 'ADD_CSS',
        SELECTOR_CSS_LIST_BY_COMMA: '#widget-richtext-hideable-12',
        CSS_TEXT: 'margin-top: 10px;'
    },
    {
        TYPE: 'ADD_CSS',
        SELECTOR_CSS_LIST_BY_COMMA: '.widget.widget-richtext strong,.widget-container.widget-container-right .widget.widget-bbcle-simplelist strong',
        CSS_TEXT: 'padding: 5px;'
    },
    {
        TYPE: 'ADD_CLASS',
        SELECTOR_CSS_LIST_BY_COMMA: '.widget-container.widget-container-right .widget.widget-bbcle-simplelist',
        CLASS_LIST_BY_SPACE: 'w3-card w3-pale-green'
    },
    {
        TYPE: 'ADD_CLASS',
        SELECTOR_CSS_LIST_BY_COMMA: '.widget-container.widget-container-right .widget.widget-bbcle-simplelist h2',
        CLASS_LIST_BY_SPACE: 'w3-blue w3-padding w3-xxxlarge w3-round'
    },
    {
        TYPE: 'ADD_CLASS',
        SELECTOR_CSS_LIST_BY_COMMA: '.widget-container.widget-container-right .widget.widget-bbcle-simplelist h3',
        CLASS_LIST_BY_SPACE: 'w3-blue w3-padding w3-xxlarge w3-round'
    },
    {
        TYPE: 'ADD_CLASS',
        SELECTOR_CSS_LIST_BY_COMMA: '.widget-container.widget-container-right .widget.widget-bbcle-simplelist strong',
        CLASS_LIST_BY_SPACE: 'w3-yellow w3-text-red w3-xxlarge w3-round'
    },
    {EMPTY_LINE: 'EMPTY_LINE'}
];
//
/* CONG JS SHORT.V?.js | FOR INJECTION WORK | 1 LINE | FUNCTIONS LIST: SELECT, GET_CDN_LINK, INJECTION_ADD_CSS_LIBRARY, INJECTION_ADD_JAVASCRIPT_LIBRARY, INJECTION_ADD_JAVASCRIPT_DATA */ function SELECT(SELECTOR_CSS) { return document.querySelector(SELECTOR_CSS); } function GET_CDN_LINK(PATH_FILE) { return 'https://gitcdn.link/cdn/congnq92/ADD-LOOK-TO-TRAINING-WEBSITE/main' + PATH_FILE; } function INJECTION_ADD_CSS_LIBRARY(PATH_FILE) { var CSS_ELEMENT = document.createElement('link'); CSS_ELEMENT.rel = 'stylesheet'; CSS_ELEMENT.href = GET_CDN_LINK(PATH_FILE); SELECT('head').appendChild(CSS_ELEMENT); } function INJECTION_ADD_JAVASCRIPT_LIBRARY(PATH_FILE){ var JAVASCRIPT_ELEMENT = document.createElement('script'); JAVASCRIPT_ELEMENT.src = GET_CDN_LINK(PATH_FILE); SELECT('head').appendChild(JAVASCRIPT_ELEMENT); } function INJECTION_ADD_JAVASCRIPT_DATA(JAVASCRIPT_TEXT){ const JAVASCRIPT_ELEMENT = document.createElement("script"); JAVASCRIPT_ELEMENT.appendChild(document.createTextNode(JAVASCRIPT_TEXT)); SELECT('head').appendChild(JAVASCRIPT_ELEMENT); }
INJECTION_ADD_CSS_LIBRARY('/CSS/CSS_ALL.V1.4.css');
INJECTION_ADD_JAVASCRIPT_LIBRARY('/JAVASCRIPT/CONG/CONG_JS.V1.49.js');
INJECTION_ADD_JAVASCRIPT_DATA('var DATA=' + JSON.stringify(DATA) + ';');